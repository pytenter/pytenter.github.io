# Ziyi Pan — Academic Homepage

A minimal, self-contained static academic website for GitHub Pages.

## Files

```text
index.html
assets/
  trajkv_figure1_motivation.png
  trajkv_figure2_method.png
```

The two PNGs were **cropped directly from the uploaded completed TrajKV manuscript** (Figure 1 on page 1 and Figure 2 on page 2), rather than recreated or edited. Keep both files in `assets/` so the homepage can display them.

## Deploy

1. Open the GitHub repository: https://github.com/pytenter/pytenter.github.io
2. Upload or replace `index.html` at the repository root.
3. Upload `assets/trajkv_figure1_motivation.png` and `assets/trajkv_figure2_method.png`, preserving those relative paths.
4. If needed, under **Settings → Pages**, choose **Deploy from a branch**, select `main`, and set the folder to `/ (root)`.
5. After the Pages deployment completes, visit https://pytenter.github.io/.

No build step or third-party scripts are required. Images and styling work without network access.

## Publication / contact notes

- TrajKV is labeled **manuscript completed**, not accepted or published.
- The full manuscript PDF is intentionally not included, because only the two paper figures were requested for the public homepage.
- No email address is displayed. Add a verified personal/school email manually if you want it public.
- The GDN/KDA research is labeled as **independent first-author, ongoing**, not a published paper.

## Visual design

The layout takes inspiration from the academic-site structure of [Gwenstadii's homepage source](https://github.com/Gwenstadii/gwenstadii.github.io), without copying its code, media, or personal content. It uses a small top navigation, airy academic sections and prominent publication figures, while avoiding animated banners and visual clutter.
